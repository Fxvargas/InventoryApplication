package com.example.newinventoryapp;

public class ItemModel {

    int id;
    String desc;
    String qty;
	String unit;

    public ItemModel() {
        super();
    }

    public ItemModel(int i, String description, String quantity) {
        super();
        this.id = i;
        this.desc = description;
        this.qty = quantity;
    }

    // constructor
    public ItemModel(String description, String quantity) {
        this.desc = description;
        this.qty = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
    public String getQty() {
        return qty;
    }
    public void setQty(String qty) {
        this.qty = qty;
    }
}
