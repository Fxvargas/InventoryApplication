package com.example.newinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Activity activity;
    Button LoginBTN, RegisterBTN;
    EditText Name, Password;
    String NameHolder, PasswordHolder;
    Boolean EmptyHolder;
    SQLiteDatabase db;
    DBActivity handler;
    String TempPassword = "NOT_FOUND" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        activity = this;

        LoginBTN = findViewById(R.id.signInBTN);
        RegisterBTN = findViewById(R.id.registerBTN);
        Name = findViewById(R.id.editTextUserName);
        Password = findViewById(R.id.editTextPassword);
        handler = new DBActivity(this);

        // Adding click listener to sign in forgotPasswordButton
        LoginBTN.setOnClickListener(view -> {
            // Call Login function
            LoginFunction();
        });

        // Adding click listener to register forgotPasswordButton.
        RegisterBTN.setOnClickListener(view -> {
            // Opening new RegisterActivity using intent on forgotPasswordButton click.
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

    }

    // Login function
    public void LoginFunction() {
        String message = CheckEditTextNotEmpty();

        if(!EmptyHolder) {
            // Opening SQLite database write permission
            db = handler.getWritableDatabase();

            // Adding search email query to cursor
            Cursor cursor = db.query(DBActivity.TABLE_NAME, null, " " + DBActivity.USER_NAME + "=?", new String[]{NameHolder}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    TempPassword = cursor.getString(cursor.getColumnIndex(DBActivity.USER_PASSWORD));
                    NameHolder = cursor.getString(cursor.getColumnIndex(DBActivity.USER_NAME));

                    // Closing cursor.
                    cursor.close();
                }
            }
            handler.close();

            // Calling method to check final result
            CheckFinalResult();
        } else {
            //If any of login EditText empty then this block will be executed.
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checking editText fields are not empty.
    public String CheckEditTextNotEmpty() {
        // Getting value from fields and storing into string variable
        String message = "";
        NameHolder = Name.getText().toString().trim();
        PasswordHolder = Password.getText().toString().trim();

        if (NameHolder.isEmpty()){
            Name.requestFocus();
            EmptyHolder = true;
            message = "User Email is Empty";
        } else if (PasswordHolder.isEmpty()){
            Password.requestFocus();
            EmptyHolder = true;
            message = "User Password is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

    // Checking entered password from SQLite database email associated password
    public void CheckFinalResult(){
        if(TempPassword.equalsIgnoreCase(PasswordHolder)) {
            Toast.makeText(MainActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();

            // Sending Name to ItemsListActivity using intent
            Bundle bundle = new Bundle();
            bundle.putString("user_name", NameHolder);

            // Going to ItemsListActivity after login success message
            Intent intent = new Intent(MainActivity.this, MainScreen.class);
            intent.putExtras(bundle);
            startActivity(intent);

            // Empty editText  after login successful and close database
            EmptyEditTextAfterDataInsert();
        } else {
            // Display error message if credentials are not correct
            Toast.makeText(MainActivity.this,"Incorrect Email or Password\nor User Not Registered",Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND" ;
    }

    // Empty edittext after login successful
    public void EmptyEditTextAfterDataInsert() {
        Name.getText().clear();
        Password.getText().clear();
    }

}