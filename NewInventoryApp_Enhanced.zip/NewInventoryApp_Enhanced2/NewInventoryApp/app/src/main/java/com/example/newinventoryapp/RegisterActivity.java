package com.example.newinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    Button RegisterBTN, CancelBTN;
    EditText newName, newPassword;
    Boolean Empty;
    SQLiteDatabase db;
    DBActivity handler;
    String F_Result = "Not_Found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        newName = findViewById(R.id.editTextUserName);
        newPassword = findViewById(R.id.editTextPassword);
        RegisterBTN = findViewById(R.id.registerButton);
        CancelBTN = findViewById(R.id.cancelButton);
        handler = new DBActivity(this);

        // This method will check if the user already exists.
        RegisterBTN.setOnClickListener(view -> {
            String message = InputValidator();

            if (!Empty) {
                CheckUser();
                ClearTextField();
            } else {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        });

        CancelBTN.setOnClickListener(view -> {
            startActivity(new Intent(RegisterActivity.this, MainActivity.class));
            this.finish();
        });
    }

    public void InsertUserIntoDatabase(){
        String name = newName.getText().toString().trim();
        String pass = newPassword.getText().toString().trim();

        UserModel user = new UserModel(name, pass);
        handler.createUser(user);

        Toast.makeText(RegisterActivity.this,"Registered", Toast.LENGTH_LONG).show();

        startActivity(new Intent(RegisterActivity.this, MainActivity.class));
        this.finish();
    }

    // Checking fields for empty values.
    public String InputValidator() {
        String message = "";
        String name = newName.getText().toString().trim();
        String pass = newPassword.getText().toString().trim();

        if (name.isEmpty()) {
            newName.requestFocus();
            Empty = true;
            message = "User Name is Empty";
        } else if (pass.isEmpty()){
            newPassword.requestFocus();
            Empty = true;
            message = "User Password is Empty";
        } else {
            Empty = false;
        }
        return message;
    }

    public void CheckUser(){
        String name = newName.getText().toString().trim();
        db = handler.getWritableDatabase();

        Cursor cursor = db.query(DBActivity.TABLE_NAME, null, " " + DBActivity.USER_NAME + "=?", new String[]{name}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                F_Result = "User exists";
                cursor.close();
            }
        }
        handler.close();

        CheckCredentials();
    }

    // Check login credentials are correct
    public void CheckCredentials(){
        if(F_Result.equalsIgnoreCase("User exists"))
        {
            Toast.makeText(RegisterActivity.this,"User exists",Toast.LENGTH_LONG).show();
        }
        else {
            InsertUserIntoDatabase();
        }
        F_Result = "Not_Found" ;
    }

    // Clears the text fields after a submit.
    public void ClearTextField(){
        newName.getText().clear();
        newPassword.getText().clear();
    }

}
