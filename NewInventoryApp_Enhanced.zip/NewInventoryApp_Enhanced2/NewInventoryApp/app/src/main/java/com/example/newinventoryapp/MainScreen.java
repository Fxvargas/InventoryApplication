package com.example.newinventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


import android.content.Intent;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.BaseAdapter;
import android.widget.ListView;

import android.widget.Toast;

import java.util.ArrayList;

public class MainScreen extends AppCompatActivity {
    FloatingActionButton addBTN;
    ListView ItemsListView;
    DBInventory db;
    ArrayList<ItemModel> items;
    ItemListAdapter itemListAdapter;
    int itemsCount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        addBTN = findViewById(R.id.addBTN);
        ItemsListView = findViewById(R.id.bodyListView);
        db = new DBInventory(this);

        items = (ArrayList<ItemModel>) db.getAllItems();

        itemsCount = db.getItemsCount();

        if (itemsCount > 0) {
            itemListAdapter = new ItemListAdapter(this, items, db);
            ItemsListView.setAdapter(itemListAdapter);
        } else {
            Toast.makeText(this, "Database is Empty", Toast.LENGTH_LONG).show();
        }

        addBTN.setOnClickListener(view -> {
            Intent add = new Intent(this, AddActivity.class);
            startActivityForResult(add, 1);
        });
    }

    // App bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_bar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.signOutBTN) {
            db.close();
            super.finish();
            Toast.makeText(this, "Signed out", Toast.LENGTH_LONG).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                itemsCount = db.getItemsCount();

                if (itemListAdapter == null) {
                    itemListAdapter = new ItemListAdapter(this, items, db);
                    ItemsListView.setAdapter(itemListAdapter);
                }
                itemListAdapter.items = (ArrayList<ItemModel>) db.getAllItems();
                ((BaseAdapter) ItemsListView.getAdapter()).notifyDataSetChanged();
            }
        }
    }
}
