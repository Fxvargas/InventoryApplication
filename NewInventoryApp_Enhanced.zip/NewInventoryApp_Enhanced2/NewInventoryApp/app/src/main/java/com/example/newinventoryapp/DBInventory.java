package com.example.newinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DBInventory extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "ItemsData.DB";
    private static final String TABLE_NAME = "Inventory";
    private static final String ITEM_ID = "id";
    private static final String ITEM_NAME = "description";
    private static final String ITEM_QUANTITY = "quantity";

    private static final String CREATE_ITEMS_TABLE = "CREATE TABLE IF NOT EXISTS " +
            TABLE_NAME + " (" +
            ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            ITEM_NAME + " VARCHAR, " +
            ITEM_QUANTITY + " VARCHAR" + ");";

    public DBInventory(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_ITEMS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void createItem(ItemModel newItem) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ITEM_NAME, newItem.getDesc());
        values.put(ITEM_QUANTITY, newItem.getQty());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public ItemModel readItem(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_NAME,
                new String[] { ITEM_ID, ITEM_NAME, ITEM_QUANTITY }, ITEM_ID + " = ?",
                new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        ItemModel item = new ItemModel(Integer.parseInt(Objects.requireNonNull(cursor).getString(0)),
                cursor.getString(1), cursor.getString(2));

        cursor.close();

        return item;
    }

    public int updateItem(ItemModel item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ITEM_NAME, item.getDesc());
        values.put(ITEM_QUANTITY, item.getQty());

        return db.update(TABLE_NAME, values, ITEM_ID + " = ?", new String[] { String.valueOf(item.getId()) });
    }
    public void deleteItem(ItemModel item) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_NAME, ITEM_ID + " = ?", new String[] { String.valueOf(item.getId()) });
        db.close();
    }

    public List<ItemModel> getAllItems() {
        List<ItemModel> itemList = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                ItemModel item = new ItemModel();
                item.setId(Integer.parseInt(cursor.getString(0)));
                item.setDesc(cursor.getString(1));
                item.setQty(cursor.getString(2));

                itemList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();

        return itemList;
    }

    public int getItemsCount() {
        String countQuery = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int itemsTotal = cursor.getCount();
        cursor.close();

        return itemsTotal;
    }
}