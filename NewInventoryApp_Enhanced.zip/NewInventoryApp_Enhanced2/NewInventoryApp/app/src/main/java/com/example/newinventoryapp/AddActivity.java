package com.example.newinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddActivity extends AppCompatActivity {

    String NameHolder, QtyHolder;
    ImageButton IncreaseQty, DecreaseQty;
    EditText ItemName, ItemQty;
    Button CancelBTN, AddBTN;
	Boolean Empty;
    DBInventory db;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_activity_layout);

        ItemName = findViewById(R.id.editTextItemName);
        IncreaseQty = findViewById(R.id.itemQtyIncrease);
        DecreaseQty = findViewById(R.id.itemQtyDecrease);
        ItemQty = findViewById(R.id.editTextItemQuantity);
        CancelBTN = findViewById(R.id.cancelButton);
        AddBTN = findViewById(R.id.addButton);
		db = new DBInventory(this);

        IncreaseQty.setOnClickListener(view -> {
            int input = 0, total;

            String value = ItemQty.getText().toString().trim();

            if (!value.isEmpty()) {
                input = Integer.parseInt(value);
            }
            total = input + 1;
            ItemQty.setText(String.valueOf(total));
        });

        DecreaseQty.setOnClickListener(view -> {
            int input, total;

            String qty = ItemQty.getText().toString().trim();

            if (qty.equals("0")) {
                Toast.makeText(this, "Invalid quantity", Toast.LENGTH_LONG).show();
            } else {
                input = Integer.parseInt(qty);
                total = input - 1;
                ItemQty.setText(String.valueOf(total));
            }
        });

        CancelBTN.setOnClickListener(view -> {
			Intent add = new Intent();
			setResult(0, add);
            this.finish();
        });

        AddBTN.setOnClickListener(view -> InsertItemIntoDatabase());
    }

    public void InsertItemIntoDatabase() {
		String message = InputValidator();

        if (!Empty) {
        	String desc = NameHolder;
        	String qty = QtyHolder;


        	ItemModel item = new ItemModel(desc, qty);
        	db.createItem(item);

            Toast.makeText(this,"Item added", Toast.LENGTH_LONG).show();

			Intent add = new Intent();
			setResult(RESULT_OK, add);
            this.finish();
        } else {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    public String InputValidator() {
		String message = "";
        NameHolder = ItemName.getText().toString().trim();
		QtyHolder = ItemQty.getText().toString().trim();

        if (NameHolder.isEmpty()) {
			ItemName.requestFocus();
            Empty = true;
            message = "Specify an item name";
        } else if (QtyHolder.isEmpty()){
			ItemQty.requestFocus();
			Empty = true;
			message = "Specify a quantity";
        } else {
        	Empty = false;
		}
        return message;
    }
}